# CodeLibrary — Website update and deployment guide

Updated: October 22, 2026

## What is included

`index.html` is the updated, mobile-friendly, static CodeLibrary website. It includes:

- **Explorer**: search by title or author; accept simple reader commands. The Explorer does **not** execute arbitrary Python/JavaScript/code.
- **Sidebar chapter commands**: type `chapter(3)` after opening a book, or use `next()`, `previous()`, or `open("Alice", 2)`. Chapter numbering begins at 1.
- **11 books in the library**: 10 classic titles linked to external full-text editions and the four-chapter *The Lantern Protocol* story embedded in the HTML.
- **Authors A–Z** instead of a catalog; **Favorites** stored locally in the current visitor's browser.
- **Code appearance** selectors: Python, JavaScript, Ruby, and C++. These are display styles, *not* execution engines.
- **Audio read-aloud**: browser text-to-speech of the currently loaded reading section, with listen, pause/resume, stop, and speed controls. No MP3 recordings are provided. Voice support/quality varies by browser/device.
- **About/Bio** section using the message: “Reading is learning. Learning is reading.”
- **No visitor `.txt` import**: the file picker and import function have been removed, with no public upload endpoint.

## Important limits

**Complete books:** Only *The Lantern Protocol* is packaged in `index.html`, so it works without the internet. The 10 classic books load their full plain-text source when opened from GITenberg repositories. The reader checks for a Project Gutenberg end-of-ebook marker and reports whether a complete download could be verified; if loading fails it does not substitute a false “complete” preview. The online requests have not been end-to-end verified in a live deployment; test each title after publishing. Chapter division is automated, and some editions may be divided into generic reading sections rather than authentic chapters. GITenberg versions are not guaranteed to track the newest editions in the live Project Gutenberg catalog.

**Owner-only import:** In the original HTML, the `.txt` import was accessible to any visitor, but it only loaded a local file into that visitor's browser; it did **not** send the file to your website/server or publish it to everyone. The new site has no import control. On a static site, a “hidden” or password-protected owner upload button implemented only in browser JavaScript would **not** be secure. To add a book privately, the owner must edit the HTML/source in the hosting repository or build a properly authenticated admin application with server-side authorization.

**Favorites:** Favorites and last-read sections use browser `localStorage` and will not sync across devices or accounts.

**Copyright:** The listed classic editions are from repositories indicating public-domain US status. Project Gutenberg states that country-specific laws and editions matter, and a minority of Project Gutenberg works are restricted. Check the rights statement inside each individual edition and the law in each visitor's publishing/access jurisdiction before distribution. Also verify any text additions, translations, illustrations, and **recorded audiobook performances** independently. *The Lantern Protocol* was already marked “CodeLibrary Original” in the uploaded file; this is not independent proof of who owns publication rights. Confirm that ownership before going live.

Helpful references:

- Project Gutenberg terms: https://www.gutenberg.org/policy/terms_of_use
- Project Gutenberg license: https://www.gutenberg.org/policy/license
- Project Gutenberg permission guidance: https://www.gutenberg.org/policy/permission.html

## Books and source IDs

| Book | Source / edition link |
|---|---|
| Alice's Adventures in Wonderland | https://www.gutenberg.org/ebooks/11 |
| Frankenstein | https://www.gutenberg.org/ebooks/84 |
| The Adventures of Sherlock Holmes | https://www.gutenberg.org/ebooks/1661 |
| Pride and Prejudice | https://www.gutenberg.org/ebooks/1342 |
| A Christmas Carol | https://www.gutenberg.org/ebooks/46 |
| The Wonderful Wizard of Oz | https://www.gutenberg.org/ebooks/55 |
| Dr. Jekyll and Mr. Hyde | https://www.gutenberg.org/ebooks/43 |
| The Time Machine | https://www.gutenberg.org/ebooks/35 |
| The Secret Garden | https://www.gutenberg.org/ebooks/113 |
| Treasure Island | https://www.gutenberg.org/ebooks/120 |
| The Lantern Protocol | Embedded four-chapter story from the prior site; ownership unverified |

## How you add more books, without letting visitors upload

1. Find a permitted public-domain edition and check its status for the relevant countries. Locate a stable plain-text source, such as a GITenberg repository.
2. In `index.html`, find `const books=[`. Add a new `remote(...)` entry using the Project Gutenberg ebook number, title, author, genre, GITenberg repository name, filename, and display symbol. Follow the existing entries as examples.
3. Verify that the source URL serves a **complete** plain-text edition. Test chapter detection and the source/footer links. Ensure the title's jurisdiction-specific rights support use.
4. Commit the modified `index.html` to the GitHub Pages repository and redeploy it. **Do not** implement owner authentication with a password embedded in HTML/JS.

If you need a true owner-only web dashboard to upload `.txt`, use a backend with real authentication, validation, access controls, storage, and a review/publish process.

## How to publish

For a new GitHub Pages site, place `index.html` in the configured publishing directory of the repository. Under **Settings → Pages**, select the publishing source and deploy. Open the resulting site over HTTPS and verify navigation, classics, read-aloud, mobile, and bookmarks. A local preview can show the original story without a network connection.

## Changing the domain

A domain **cannot** be changed by editing only the HTML file. You must control the hosting repository and DNS records for the intended new domain.

For GitHub Pages: first verify ownership of the new domain if possible; then open **Repository → Settings → Pages → Custom domain**, enter and save the domain; then update DNS at your domain registrar to point to the GitHub Pages host (a `CNAME` for `www`, or the prescribed apex records for the bare domain). Make sure HTTPS is enabled. A GitHub Pages branch deployment usually generates a `CNAME` file when the custom domain is saved. Do not include a `CNAME` until you know the real domain.

Current GitHub instructions: https://docs.github.com/en/pages/configuring-a-custom-domain-for-your-github-pages-site/managing-a-custom-domain-for-your-github-pages-site

## The three dots and `hello.py`

The red, yellow, green circles in the upper bar are visual symbols that imitate an editor's window controls; they are **not clickable controls**. The `hello.py` text is a decorative filename for the starting explorer screen. The `.py` extension means Python, but the site itself is written in HTML, CSS, and JavaScript and isn't actually running that file.
